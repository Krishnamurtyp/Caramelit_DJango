from django.shortcuts import render,redirect



def base(request):
    return render(request, "base.html")

def student(request):
    return render(request, "student.html")

def student_courses(request):
    return render(request, "student_courses.html")

def exam_report(request):
    return render(request, "exam_report.html")

def wishlist(request):
    return render(request, "wishlist.html")

def cart(request):
    return render(request, "cart.html")

def reward(request):
    return render(request, "reward.html")


def organisation(request):
    return render(request, "organisation.html")

def organisation_courses(request):
    return render(request, "organisation_courses.html")

def instructor_notify(request):
    return render(request, "instructor_notify.html")


def college(request):
    return render(request, "college.html")

def college_courses(request):
    return render(request, "college_courses.html")

def college_notify(request):
    return render(request, "college_notify.html")

def instructor(request):
    return render(request, "instructor.html")

def manage_students(request):
    return render(request, "manage_students.html")

def manage_skills(request):
    return render(request, "manage_skills.html")

def choose_course(request):
    return render(request, "choose_course.html")

def list_course(request):
    return render(request, "list_course.html")

def dissociate_course(request):
    return render(request, "dissociate_course.html")