"""dashboard URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from dashboard import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.base, name='base'),
    path('student', views.student, name='student'),
    path('student_courses', views.student_courses, name='student_courses'),
    path('exam_report', views.exam_report, name='exam_report'),
    path('wishlist', views.wishlist, name='wishlist'),
    path('cart', views.cart, name='cart'),
    path('reward', views.reward, name='reward'),
    path('organisation', views.organisation, name='organisation'),
    path('organisation_courses', views.organisation_courses, name='organisation_courses'),
    path('instructor_notify', views.instructor_notify, name='instructor_notify'),
    path('college', views.college, name='college'),
    path('college_courses', views.college_courses, name='college_courses'),
    path('college_notify', views.college_notify, name='college_notify'),
    path('instructor', views.instructor, name='instructor'),
    path('manage_students', views.manage_students, name='manage_students'),
    path('manage_skills', views.manage_skills, name='manage_skills'),
    path('choose_course', views.choose_course, name='choose_course'),
    path('list_course', views.list_course, name='list_course'),
    path('dissociate_course', views.dissociate_course, name='dissociate_course'),
]
